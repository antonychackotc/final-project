import streamlit as st
import pandas as pd
import joblib
from datetime import date
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# Load the trained model
log_reg = joblib.load('logistic_regression_fraud_model.pkl')

# Read the dataset
df1 = pd.read_csv('/content/df3_upd_labels.csv')

# Get min and max values for the required columns
min_values = df1[['Annual_Income', 'Claim_Amount']].min()
max_values = df1[['Annual_Income', 'Claim_Amount']].max()
min_max_values = np.array([min_values, max_values])

# Fit the scaler on known ranges
scaler = MinMaxScaler(feature_range=(0, 1))
scaler.fit(min_max_values)

# Feature list used during training
training_features = ['Claim_Amount', 'Suspicious_Flags', 'Claim_Type_Home_Damage', 'Claim_Type_Medical',
                     'Claim_Type_Vehicle', 'Claim_Year', 'Claim_Month', 'Claim_Day', 'Annual_Income',
                     'Claim_to_Income_Ratio', 'Days_Since_Issuance', 'Short_Period_Claim', 'Isolation_Anomaly',
                     'policy_issue_Year', 'policy_issue_Month', 'policy_issue_Day']

# Function to calculate days since policy issuance
def calculate_days_since_issuance(claim_date, policy_issue_date):
    delta = claim_date - policy_issue_date
    return delta.days

# Function to prepare input data
def prepare_input_data(user_input):
    # Scale Claim_Amount and Annual_Income
    scaled_values = scaler.transform([[user_input['Annual_Income'], user_input['Claim_Amount']]])
    user_input['Annual_Income'], user_input['Claim_Amount'] = scaled_values[0]

    # Map Claim_Type to one-hot encoded columns
    claim_type_mapping = {
        'Home Damage': [1, 0, 0],
        'Medical': [0, 1, 0],
        'Vehicle': [0, 0, 1]
    }
    user_input['Claim_Type_Home_Damage'], user_input['Claim_Type_Medical'], user_input['Claim_Type_Vehicle'] = claim_type_mapping[user_input['Claim_Type']]

    # Calculate engineered features
    user_input['Claim_to_Income_Ratio'] = user_input['Claim_Amount'] / user_input['Annual_Income']
    user_input['Suspicious_Flags'] = 1 if user_input['Claim_to_Income_Ratio'] > 0.5 else 0

    # Calculate days since policy issuance
    claim_date = date(user_input['Claim_Year'], user_input['Claim_Month'], user_input['Claim_Day'])
    policy_issue_date = date(user_input['policy_issue_Year'], user_input['policy_issue_Month'], user_input['policy_issue_Day'])
    user_input['Days_Since_Issuance'] = calculate_days_since_issuance(claim_date, policy_issue_date)

    # Determine if it's a short-period claim
    user_input['Short_Period_Claim'] = 1 if user_input['Days_Since_Issuance'] < 365 else 0

    # Updated Isolation Anomaly detection using refit approach
    sample_data = pd.DataFrame([[user_input['Claim_Amount'], user_input['Claim_Year'], user_input['Claim_Month'], user_input['Claim_Day'], user_input['Claim_to_Income_Ratio'], user_input['Days_Since_Issuance']]])
    iso_forest = IsolationForest(contamination=0.20, random_state=42)
    user_input['Isolation_Anomaly'] = iso_forest.fit_predict(sample_data)[0]

    # Align feature names and order
    input_data = pd.DataFrame([user_input])[training_features]

    return input_data, user_input, claim_date, policy_issue_date

# Streamlit app
st.title('Insurance Fraud Detection App')

# Collect user input
claim_amount = st.number_input('Claim Amount', min_value=0.00)
claim_type = st.selectbox('Claim Type', ['Home Damage', 'Medical', 'Vehicle'])
claim_year = st.number_input('Claim Year', min_value=2000, max_value=2100)
claim_month = st.number_input('Claim Month', min_value=1, max_value=12)
claim_day = st.number_input('Claim Day', min_value=1, max_value=31)
annual_income = st.number_input('Annual Income', min_value=0.00)
policy_issue_year = st.number_input('Policy Issue Year', min_value=2000, max_value=2100)
policy_issue_month = st.number_input('Policy Issue Month', min_value=1, max_value=12)
policy_issue_day = st.number_input('Policy Issue Day', min_value=1, max_value=31)

# Prepare input and predict if the user clicks the button
if st.button('Predict Fraud Risk'):
    user_input = {
        'Claim_Amount': claim_amount,
        'Claim_Type': claim_type,
        'Claim_Year': claim_year,
        'Claim_Month': claim_month,
        'Claim_Day': claim_day,
        'Annual_Income': annual_income,
        'policy_issue_Year': policy_issue_year,
        'policy_issue_Month': policy_issue_month,
        'policy_issue_Day': policy_issue_day
    }

    prepared_data, user_input_features, claim_date, policy_issue_date = prepare_input_data(user_input)
    prediction = log_reg.predict(prepared_data)
    result = 'FRAUD' if prediction[0] == 1 else 'GENUINE'
    st.success(f'Predicted class: {result}')

    st.write(f"Claim Date: {claim_date}")
    st.write(f"Policy Issue Date: {policy_issue_date}")
    st.write(f"Days Since Issuance: {user_input_features['Days_Since_Issuance']}")

    # Show calculated feature values
    st.write(f"Claim to Income Ratio: {user_input_features['Claim_to_Income_Ratio']}")
    st.write(f"Suspicious Flags: {'True' if user_input_features['Suspicious_Flags'] == 1 else 'False'}")
    st.write(f"Short Period Claim: {'True' if user_input_features['Short_Period_Claim'] == 1 else 'False'}")
    st.write(f"Isolation Anomaly: {'Anomaly' if user_input_features['Isolation_Anomaly'] == -1 else 'Normal'}")
    st.write(f"Scaled Annual Income: {user_input_features['Annual_Income']}")
    st.write(f"Scaled Claim Amount: {user_input_features['Claim_Amount']}")
