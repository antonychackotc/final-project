
import streamlit as st
from transformers import MBartForConditionalGeneration, MBart50TokenizerFast

# Load the mBART model and tokenizer
@st.cache_resource()
def load_model():
    model_name = "facebook/mbart-large-50"
    tokenizer = MBart50TokenizerFast.from_pretrained(model_name)
    model = MBartForConditionalGeneration.from_pretrained(model_name)
    return model, tokenizer

model, tokenizer = load_model()

# Streamlit UI
st.title("Text Summarization with Facebook's mBART")

text = st.text_area("Enter the text you want to summarize:")

if st.button("Summarize"):
    if text:
        # Tokenize input text
        inputs = tokenizer(text, return_tensors="pt", max_length=1024, truncation=True)

        # Generate summary
        summary_ids = model.generate(**inputs, max_length=150, min_length=30, length_penalty=2.0, num_beams=4, early_stopping=True)

        # Decode and display summary
        summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
        st.subheader("Summary:")
        st.write(summary)
    else:
        st.warning("Please enter some text to summarize!")

